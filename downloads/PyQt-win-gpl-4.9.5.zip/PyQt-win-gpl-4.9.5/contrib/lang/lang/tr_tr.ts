<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>Title</source>
        <translation type="unfinished">Ünvan</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Metin</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Dil</translation>
    </message>
</context>
</TS>
