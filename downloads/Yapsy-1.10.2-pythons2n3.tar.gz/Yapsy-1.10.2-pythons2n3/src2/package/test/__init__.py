"""
Gathers the unittests of yapsy
"""
