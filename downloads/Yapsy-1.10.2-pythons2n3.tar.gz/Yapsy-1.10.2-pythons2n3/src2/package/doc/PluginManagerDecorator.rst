======================
PluginManagerDecorator
======================

.. toctree::
   :maxdepth: 2


.. automodule:: yapsy.PluginManagerDecorator
   :members:
   :undoc-members:   

