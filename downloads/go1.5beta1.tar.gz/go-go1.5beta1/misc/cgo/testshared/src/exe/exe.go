package main

import "dep"

func main() {
	dep.V = dep.F() + 1
}
