******
colors
******


:mod:`matplotlib.colors`
========================

.. automodule:: matplotlib.colors
   :members:
   :undoc-members:
   :show-inheritance:
