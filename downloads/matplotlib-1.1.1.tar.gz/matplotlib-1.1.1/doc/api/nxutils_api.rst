*******
nxutils
*******

:mod:`matplotlib.nxutils`
===========================

.. automodule:: matplotlib.nxutils
   :members:
   :undoc-members:
   :show-inheritance:

