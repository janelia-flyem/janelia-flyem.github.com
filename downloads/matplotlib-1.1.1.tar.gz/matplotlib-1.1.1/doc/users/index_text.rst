.. _text-guide:

Working with text
#################

.. toctree::

    text_intro.rst
    text_props.rst
    mathtext.rst
    usetex.rst
    annotations_intro.rst


