
:mod:`mpl_toolkits.axes_grid.axis_artist`
=========================================

.. autoclass:: mpl_toolkits.axes_grid.axis_artist.AxisArtist
   :members:
   :undoc-members:

.. autoclass:: mpl_toolkits.axes_grid.axis_artist.Ticks
   :members:

.. autoclass:: mpl_toolkits.axes_grid.axis_artist.AxisLabel
   :members:

.. autoclass:: mpl_toolkits.axes_grid.axis_artist.TickLabels
   :members:
