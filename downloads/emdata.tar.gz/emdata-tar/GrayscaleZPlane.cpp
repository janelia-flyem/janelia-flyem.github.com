// Copyright 2012 HHMI.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of HHMI nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: katzw@janelia.hhmi.org (Bill Katz)
//  Written as part of the FlyEM Project at Janelia Farm Research Center.

#include <string>
#include <iostream>

#include <boost/shared_ptr.hpp>
#include <boost/lexical_cast.hpp>

#include <transport/TTransportUtils.h>
#include <transport/TFileTransport.h>
#include <transport/TSimpleFileTransport.h>
#include <protocol/TBinaryProtocol.h>
//#include <protocol/TDenseProtocol.h>   -- Experimental so don't use.
//#include <protocol/TCompactProtocol.h> -- Fails on Mac due to right shift error

#include "GrayscaleZPlane.h"
#include "ThriftObject.h"
#include "emdata.h"

using std::string;
using std::cout;
using std::cerr;
using std::endl;
using std::ostringstream;

using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

namespace emdata {


GrayscaleZPlane::GrayscaleZPlane(const VoxelCoord slice, const Vector3d resolution)
{
    slice_ = slice;
    resolution_ = resolution;
}

void GrayscaleZPlane::Encode(const LabelId bodyId, const VoxelPt &pt,
                             const unsigned char value)
{
    VoxelList& voxels = voxelListMap_.data[bodyId];

    // See if we have an encoder for this body.  If not, construct one and info.
    BodyEncodingMap::iterator it = bodyEncodingMap_.find(bodyId);
    if (it != bodyEncodingMap_.end()) {
        VoxelEncoder& encoder = it->second;
        encoder.AppendVoxel(pt, value);
        voxels.numVoxels += 1;
        if (voxels.bounds.minPoint.y > pt.y) {
            voxels.bounds.minPoint.y = pt.y;
        }
        if (voxels.bounds.maxPoint.y < pt.y) {
            voxels.bounds.maxPoint.y = pt.y;
        }
        if (voxels.bounds.minPoint.x > pt.x) {
            voxels.bounds.minPoint.x = pt.x;
        }
        if (voxels.bounds.maxPoint.x < pt.x) {
            voxels.bounds.maxPoint.x = pt.x;
        }
    } else {
        voxels.valueType = VoxelValue::BITS8;
        voxels.slicingType = Slicing::Z;
        voxels.normalStored = false;
        voxels.numVoxels = 1;
        voxels.numSurfaceVoxels = 0;
        voxels.resolution = resolution_;
        voxels.bounds.minPoint.x = pt.x;
        voxels.bounds.minPoint.y = pt.y;
        voxels.bounds.minPoint.z = slice_;
        voxels.bounds.maxPoint.x = pt.x;
        voxels.bounds.maxPoint.y = pt.y;
        voxels.bounds.maxPoint.z = slice_;

        bodyEncodingMap_[bodyId] = VoxelEncoder(VoxelValue::BITS8, Slicing::Z);            
        bodyEncodingMap_[bodyId].AppendVoxel(pt, value);
    }
}

bool GrayscaleZPlane::Write(const string directory)
{
    // Grab all the encodings
    voxelListMap_.numBodies = voxelListMap_.data.size();
    VoxelListMapData::iterator it = voxelListMap_.data.begin();
    for (; it != voxelListMap_.data.end(); ++it) {
        VoxelEncoder& encoder = bodyEncodingMap_[it->first];
        it->second.encodedData = encoder.GetEncoding();
    }

     // Make thrift filename with slice number
    std::ostringstream ss;
    ss << "grayscalevoxels-" << slice_ << ".tdf";
    string filename = directory + "/" + ss.str();

    // Serialize to file
    ThriftObject<VoxelListMap> thriftObject;
    thriftObject.Write(filename, voxelListMap_);

    // Print some debugging information about surfaces obtained.
    cout << "\nSaved " << voxelListMap_.numBodies << " bodies for slice " 
         << slice_ << ":" << endl;
    int totalVoxels = 0;
    int totalBytes = 0;
    it = voxelListMap_.data.begin();
    for (; it != voxelListMap_.data.end(); ++it) {
        Bounds3d& bounds = it->second.bounds;
        cout << "Body " << it->first << ": "
             << it->second.numVoxels << " voxels, "
             << it->second.encodedData.size() << " bytes. " 
             << "Bounds: " << pt_to_string(bounds.minPoint) << " to "
             << pt_to_string(bounds.maxPoint) << endl;
        totalVoxels += it->second.numVoxels;
        totalBytes += it->second.encodedData.size();
    }
    double overhead = (100.0 * totalBytes) / totalVoxels - 100.0;
    cout << "Total of " << totalVoxels << " voxels, "
         << totalBytes << " bytes ("
         << overhead << "% overhead) for slice "
         << slice_ << endl;

    return true;
}


} // emdata namespace
