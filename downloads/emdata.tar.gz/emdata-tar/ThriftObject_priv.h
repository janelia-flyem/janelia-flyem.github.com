// Copyright 2012 HHMI.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of HHMI nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: katzw@janelia.hhmi.org (Bill Katz)
//  Written as part of the FlyEM Project at Janelia Farm Research Center.

#ifndef __THRIFTOBJECT_PRIV_H__
#define __THRIFTOBJECT_PRIV_H__

#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>

#include <boost/shared_ptr.hpp>
#include <boost/lexical_cast.hpp>

#include <transport/TTransportUtils.h>
#include <transport/TFileTransport.h>
#include <transport/TSimpleFileTransport.h>
#include <protocol/TBinaryProtocol.h>
//#include <protocol/TDenseProtocol.h>   -- Experimental so don't use.
//#include <protocol/TCompactProtocol.h> -- Fails on Mac due to right shift error

namespace emdata {

template <typename T>
bool ThriftObject<T>::Write(const std::string filename, const T& thriftObj, 
                            bool overwrite)
{
    if (overwrite && remove(filename.c_str()) == 0) {
        std::cout << "-- Removed previous thrift file: " 
                  << filename << std::endl;
    }

    // Open transport (apache::thrift::transport::TTransport)
    boost::shared_ptr<apache::thrift::transport::TTransport> otransport(
        new apache::thrift::transport::TSimpleFileTransport(filename, false, true));
    boost::shared_ptr<apache::thrift::transport::TBufferedTransport> obtransport(
        new apache::thrift::transport::TBufferedTransport(otransport));
    
    // Open protocol (apache::thrift::protocol::TProtocol)
    boost::shared_ptr<apache::thrift::protocol::TProtocol> oprotocol(
        new apache::thrift::protocol::TBinaryProtocol(obtransport));

    // Serialize to file using thrift
    obtransport->open();
    thriftObj.write(oprotocol.get());
    obtransport->close();
    return true;
}

template <typename T>
bool ThriftObject<T>::Read(const std::string filename, T *thriftObj)
{
    try {
        // Read in thrift file.
        boost::shared_ptr<apache::thrift::transport::TTransport> itransport(
            new apache::thrift::transport::TSimpleFileTransport(filename, true, false));
        boost::shared_ptr<apache::thrift::transport::TBufferedTransport> ibtransport(
            new apache::thrift::transport::TBufferedTransport(itransport));

        // Open protocol (apache::thrift::protocol::TProtocol)
        boost::shared_ptr<apache::thrift::protocol::TProtocol> iprotocol(
            new apache::thrift::protocol::TBinaryProtocol(ibtransport));

        // Serialize from file using thrift
        ibtransport->open();
        thriftObj->read(iprotocol.get());
        ibtransport->close();
        return true;
    } catch (...) {
        return false;
    }
}

template <class T>
void ThriftObject<T>::Serialize(const T& thriftObj, std::string *serializedData)
{
    boost::shared_ptr<apache::thrift::transport::TMemoryBuffer> 
        memBuf(new apache::thrift::transport::TMemoryBuffer());
    boost::shared_ptr<apache::thrift::protocol::TBinaryProtocol> 
        binProt(new apache::thrift::protocol::TBinaryProtocol(memBuf));
    thriftObj.write(binProt.get());
    *serializedData = memBuf->getBufferAsString();
}
    
template <class T>
void ThriftObject<T>::Deserialize(const std::string& serializedData, T *thriftObj)
{
    uint8_t* dPtr = (uint8_t*)(serializedData.data());
    boost::shared_ptr<apache::thrift::transport::TMemoryBuffer> 
        memBuf(new apache::thrift::transport::TMemoryBuffer(
                dPtr, serializedData.size()));
    boost::shared_ptr<apache::thrift::protocol::TBinaryProtocol> 
        binProt(new apache::thrift::protocol::TBinaryProtocol(memBuf));
    thriftObj->read(binProt.get());
}
    
}   // emdata namespace

#endif
