// Copyright 2012 HHMI.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of HHMI nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: katzw@janelia.hhmi.org (Bill Katz)
//  Written as part of the FlyEM Project at Janelia Farm Research Center.

#include <string>

#include <leveldb/cache.h>

#include "VoxelDatastore.h"
#include "ThriftObject.h"

using std::string;
using std::cerr;
using std::cout;
using std::endl;

namespace emdata {

typedef unsigned char DatastoreTypeKey;

const DatastoreTypeKey BODY_INFO = 1;
const DatastoreTypeKey VOXEL_DATA = 2;

VoxelDatastore::VoxelDatastore(const string datastorePath, 
    size_t cacheSize, size_t writeBufferSize)
{
    datastorePath_ = datastorePath;
    leveldb::Options options;
    options.create_if_missing = true;
    cout << "LevelDB default compression: "
         << options.compression << endl;
    cout << "LevelDB block size: "
         << options.block_size << " changed to ";
    options.block_size = 1024 * 4096;
    cout << options.block_size << endl;

    cout << "LevelDB write buffer size: "
         << options.write_buffer_size << " changed to ";
    options.write_buffer_size = writeBufferSize;
    options.block_cache = leveldb::NewLRUCache(cacheSize);
    cout << options.write_buffer_size << endl;

    // Set leveldb cache to generous amount

    leveldb::Status status = leveldb::DB::Open(options, datastorePath, &pLevelDb_);
    if (!status.ok()) {
    	cerr << "Unable to open voxel datastore at the following path:" << endl;
    	cerr << "  " << datastorePath << endl;
    	if (status.IsNotFound()) {
    		cerr << "Datastore not found at the path." << endl;
    	} else if (status.IsCorruption()) {
    		cerr << "Datastore corrupted." << endl;
    	} else if (status.IsIOError()) {
    		cerr << "Had IO Error." << endl;
    	}
    	cerr << "Quitting..." << endl;
    	exit(1);
    }
}

VoxelDatastore::~VoxelDatastore()
{
	delete pLevelDb_;
}

string VoxelDatastore::KeyForBodyZ(const LabelId bodyId, const VoxelCoord z)
{
    string key;
    key.append((const char*)(&bodyId), sizeof(LabelId));
    key.append((const char*)(&VOXEL_DATA), sizeof(DatastoreTypeKey));
    key.append((const char*)(&z), sizeof(VoxelCoord));
    return key;
}

string VoxelDatastore::KeyForBodyInfo(const LabelId bodyId)
{
    string key;
    key.append((const char*)(&bodyId), sizeof(LabelId));
    key.append((const char*)(&BODY_INFO), sizeof(DatastoreTypeKey));
    return key;
}

bool VoxelDatastore::PutZData(const VoxelCoord z, const VoxelListMap& voxelListMap)
{
    ThriftObject<VoxelList> thriftObject;

    // We need to split up the surfaces for each body 
    leveldb::WriteOptions writeOptions;
    VoxelListMapData::const_iterator it = voxelListMap.data.begin();
    for (; it != voxelListMap.data.end(); ++it) {
        string key = KeyForBodyZ(it->first, z);
        string serializedData;
        thriftObject.Serialize(it->second, &serializedData);
        leveldb::Status s = pLevelDb_->Put(writeOptions, key, serializedData);
        if (!s.ok()) {
            return false;
        }
    }

    return true;
}

bool VoxelDatastore::PutBodyInfo(const BodyInfo& bodyInfo)
{
    string key = KeyForBodyInfo(bodyInfo.bodyId);
    string serializedData;
    ThriftObject<BodyInfo> thriftObject;
    thriftObject.Serialize(bodyInfo, &serializedData);

    leveldb::WriteOptions writeOptions;
    leveldb::Status s = pLevelDb_->Put(writeOptions, key, serializedData);
    if (!s.ok()) {
        return false;
    }

    return true;
}

bool VoxelDatastore::GetBodyInfo(const LabelId bodyId, BodyInfo *pBodyInfo)
{
    string key = KeyForBodyInfo(bodyId);
    string serializedData;
    leveldb::ReadOptions readOptions;
    leveldb::Status s = pLevelDb_->Get(readOptions, key, &serializedData);
    if (!s.ok()) {
        return false;
    }

    ThriftObject<BodyInfo> thriftObject;
    thriftObject.Deserialize(serializedData, pBodyInfo);
    return true;
}


} // emdata namespace
