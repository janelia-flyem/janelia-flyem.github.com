// Copyright 2012 HHMI.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of HHMI nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: katzw@janelia.hhmi.org (Bill Katz)
//  Written as part of the FlyEM Project at Janelia Farm Research Center.

#include <stdexcept>
#include <math.h>
#include "gtest/gtest.h"
#include "VoxelEncoder.h"
#include "emdata.h"

using namespace emdata;
using std::string;
using std::cout;
using std::endl;
using std::flush;

// This is big because we use few bits and shading not critical
const double ComponentTolerance = 0.05;
const double CosineTolerance = 0.01;

void test_vector3d(const Vector3d& a, const Vector3d& b)
{
    EXPECT_NEAR(a.x, b.x, ComponentTolerance) 
        << "X component error for vectors "
        << vec_to_string(a) << " and " << vec_to_string(b);
    EXPECT_NEAR(a.y, b.y, ComponentTolerance)
        << "Y component error for vectors "
        << vec_to_string(a) << " and " << vec_to_string(b);
    EXPECT_NEAR(a.z, b.z, ComponentTolerance)
        << "Z component error for vectors "
        << vec_to_string(a) << " and " << vec_to_string(b);
}

TEST(VoxelEncoder, EncodeVoxel) 
{
    VoxelEncoder encoder;
    
    VoxelPt pt;
    pt.x = 10;
    pt.y = 20;
    pt.z = 30;
    
    uint8_t value = 100;
    encoder.AppendVoxel(pt, value);
    pt.x += 1;
    value += 1;
    encoder.AppendVoxel(pt, value);
    pt.x += 1;
    value += 1;
    encoder.AppendVoxel(pt, value);
    
    encoder.SeekToFirst();
    EXPECT_EQ(100, encoder.Get8BitValue()) << "After seek value wrong";
    VoxelPt gotPoint;
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(10, gotPoint.x) << "After seek voxel pt wrong";
    EXPECT_TRUE(encoder.Valid()) << "After seek invalid";

    encoder.Next();
    EXPECT_EQ(101, encoder.Get8BitValue()) << "After Next value wrong";
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(11, gotPoint.x) << "After Next voxel pt wrong";
    EXPECT_TRUE(encoder.Valid()) << "After Next invalid";

    encoder.Next();
    EXPECT_EQ(102, encoder.Get8BitValue()) << "After 2nd Next value wrong";
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(12, gotPoint.x) << "After 2nd Next voxel pt wrong";
    EXPECT_TRUE(encoder.Valid()) << "After 2nd Next invalid";

    encoder.Next();
    EXPECT_FALSE(encoder.Valid()) << "Beyond buffer is incorrectly Valid";
}

TEST(VoxelEncoder, EncodeVoxelNormal) 
{
    VoxelEncoder encoder(VoxelValue::BITS8, Slicing::Z, true);
    
    VoxelPt pt;
    pt.x = 10;
    pt.y = 20;
    pt.z = 30;
    uint8_t value = 100;

    Vector3d normal;
    normal.x = 34.8;
    normal.y = -12.3;
    normal.z = 81.2;
    double magnitude = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
    normal.x /= magnitude;
    normal.y /= magnitude;
    normal.z /= magnitude;
    double new_mag = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
    EXPECT_NEAR(new_mag, 1.0, 0.01);

    encoder.AppendSurface(pt, value, normal);
    pt.x += 1;
    value += 1;
    encoder.AppendSurface(pt, value, normal);
    pt.x += 1;
    value += 1;
    encoder.AppendSurface(pt, value, normal);
    
    encoder.SeekToFirst();
    EXPECT_EQ(100, encoder.Get8BitValue()) << "After seek value wrong";
    VoxelPt gotPoint;
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(10, gotPoint.x) << "After seek voxel pt wrong";
    Vector3d gotNormal;
    encoder.GetNormal(&gotNormal);
    test_vector3d(normal, gotNormal);
    EXPECT_TRUE(encoder.Valid()) << "After seek invalid";

    encoder.Next();
    EXPECT_EQ(101, encoder.Get8BitValue()) << "After Next value wrong";
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(11, gotPoint.x) << "After Next voxel pt wrong";
    encoder.GetNormal(&gotNormal);
    test_vector3d(normal, gotNormal);
    EXPECT_TRUE(encoder.Valid()) << "After Next invalid";

    encoder.Next();
    EXPECT_EQ(102, encoder.Get8BitValue()) << "After 2nd Next value wrong";
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(12, gotPoint.x) << "After 2nd Next voxel pt wrong";
    encoder.GetNormal(&gotNormal);
    test_vector3d(normal, gotNormal);
    EXPECT_TRUE(encoder.Valid()) << "After 2nd Next invalid";

    encoder.Next();
    EXPECT_FALSE(encoder.Valid()) << "Beyond buffer is incorrectly Valid";
}

TEST(VoxelEncoder, RoundTrip8bitSpans)
{
    VoxelEncoder encoder(VoxelValue::BITS8, Slicing::Z);

    VoxelPt pt;
    pt.x = 10;
    pt.y = 20;
    pt.z = 30;
    uint8_t value = 100;

    VoxelPt start = pt;
    uint8_t startValue = value;

    for (int i = 0; i < 5; ++i) {
        encoder.AppendVoxel(pt, value);
        pt.x += 1;
        value += 2;
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        encoder.AppendVoxel(pt, value);
        pt.x += 1;
        value += 3;
    }
    // Check multiple Z slices
    pt.z += 44;
    value -= 10;
    for (int i = 0; i < 8; ++i) {
        encoder.AppendVoxel(pt, value);
        pt.x += 1;
        value -= 1;
    }
    pt.z += 1;
    pt.y += 13;
    for (int i = 0; i < 4; ++i) {
        encoder.AppendVoxel(pt, value);
        pt.x += 1;
        value += 2;
    }

    // Check if we get it back.
    VoxelPt gotPoint;
    encoder.SeekToFirst();
    pt = start;
    value = startValue;
    for (int i = 0; i < 5; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 1, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 1, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 1, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 1, voxel " << i  
            << ": Value retrieved not identical";
        pt.x += 1;
        value += 2;
        encoder.Next();
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 2, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 2, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 2, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 2, voxel " << i  
            << ": Value retrieved not identical";
        pt.x += 1;
        value += 3;
        encoder.Next();
    }
    pt.z += 44;
    value -= 10;
    for (int i = 0; i < 8; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Slice 2, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Slice 2, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Slice 2, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Slice 2, voxel " << i  
            << ": Value retrieved not identical";
        pt.x += 1;
        value -= 1;
        encoder.Next();
    }
    pt.z += 1;
    pt.y += 13;
    for (int i = 0; i < 4; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Slice 3, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Slice 3, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Slice 3, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Slice 3, voxel " << i  
            << ": Value retrieved not identical";
        pt.x += 1;
        value += 2;
        encoder.Next();
    }
}

TEST(VoxelEncoder, RoundTrip8bitNormalSpans)
{
    VoxelEncoder encoder(VoxelValue::BITS8, Slicing::Z, true, 0); //, true);
    
    VoxelPt pt;
    pt.x = 10;
    pt.y = 20;
    pt.z = 30;
    uint8_t value = 100;

    Vector3d normal;
    normal.x = 34.8;
    normal.y = -12.3;
    normal.z = 81.2;
    double magnitude = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
    normal.x /= magnitude;
    normal.y /= magnitude;
    normal.z /= magnitude;
    double new_mag = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
    EXPECT_NEAR(new_mag, 1.0, 0.01);

    VoxelPt start = pt;
    uint8_t startValue = value;
    Vector3d startNormal = normal;

    for (int i = 0; i < 5; ++i) {
        encoder.AppendSurface(pt, value, normal);
        pt.x += 1;
        value += 2;
        normal.x += 0.1;
        normal.z -= 0.1;
        magnitude = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
        normal.x /= magnitude;
        normal.y /= magnitude;
        normal.z /= magnitude;
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        encoder.AppendSurface(pt, value, normal);
        pt.x += 1;
        value += 3;
        normal.y += 0.03;
        normal.z += 0.04;
        magnitude = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
        normal.x /= magnitude;
        normal.y /= magnitude;
        normal.z /= magnitude;
    }

    // Check if we get it back.
    encoder.SeekToFirst();
    pt = start;
    value = startValue;
    normal = startNormal;
    VoxelPt gotPoint;
    for (int i = 0; i < 5; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 1, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 1, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 1, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 1, voxel " << i  
            << ": Value retrieved not identical";
        Vector3d gotNormal;
        encoder.GetNormal(&gotNormal);
        test_vector3d(normal, gotNormal);
        pt.x += 1;
        value += 2;
        normal.x += 0.1;
        normal.z -= 0.1;
        magnitude = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
        normal.x /= magnitude;
        normal.y /= magnitude;
        normal.z /= magnitude;
        encoder.Next();
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 2, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 2, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 2, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 2, voxel " << i  
            << ": Value retrieved not identical";
        Vector3d gotNormal;
        encoder.GetNormal(&gotNormal);
        test_vector3d(normal, gotNormal);
        pt.x += 1;
        value += 3;
        normal.y += 0.03;
        normal.z += 0.04;
        magnitude = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z* normal.z);
        normal.x /= magnitude;
        normal.y /= magnitude;
        normal.z /= magnitude;
        encoder.Next();
    }
}

TEST(VoxelEncoder, RoundTrip8bitMagSpans)
{
    VoxelEncoder encoder(VoxelValue::BITS8, Slicing::Z, true);

    VoxelPt pt;
    pt.x = 10;
    pt.y = 20;
    pt.z = 30;
    uint8_t value = 100;
    double magnitude = 21.6;

    VoxelPt start = pt;
    uint8_t startValue = value;
    double startMagnitude = magnitude;

    for (int i = 0; i < 5; ++i) {
        encoder.AppendInterior(pt, value, magnitude);
        pt.x += 1;
        value += 2;
        magnitude += 2.33;
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        encoder.AppendInterior(pt, value, magnitude);
        pt.x += 1;
        value += 3;
        magnitude -= 1.7;
    }

    // Check if we get it back.
    encoder.SeekToFirst();
    pt = start;
    value = startValue;
    VoxelPt gotPoint;
    magnitude = startMagnitude;
    for (int i = 0; i < 5; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        double gotMagnitude = encoder.GetMagnitude();
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 1, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 1, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 1, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 1, voxel " << i  
            << ": Value retrieved not identical";
        EXPECT_NEAR(magnitude, gotMagnitude, 1.0);
        pt.x += 1;
        value += 2;
        magnitude += 2.33;
        encoder.Next();
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        double gotMagnitude = encoder.GetMagnitude();
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 2, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 2, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 2, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 2, voxel " << i  
            << ": Value retrieved not identical";
        EXPECT_NEAR(magnitude, gotMagnitude, 1.0);
        pt.x += 1;
        value += 3;
        magnitude -= 1.7;
        encoder.Next();
    }
}

TEST(VoxelEncoder, RoundTrip16bitSpans)
{
    VoxelEncoder encoder(VoxelValue::BITS16, Slicing::Z);

    VoxelPt pt;
    pt.x = 10;
    pt.y = 20;
    pt.z = 30;
    uint16_t value = 100;

    VoxelPt start = pt;
    uint16_t startValue = value;

    for (int i = 0; i < 5; ++i) {
        encoder.AppendVoxel(pt, value);
        pt.x += 1;
        value += 2;
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        encoder.AppendVoxel(pt, value);
        pt.x += 1;
        value += 3;
    }

    // Check if we get it back.
    encoder.SeekToFirst();
    pt = start;
    value = startValue;
    VoxelPt gotPoint;
    for (int i = 0; i < 5; ++i) {
        uint16_t gotValue = encoder.Get16BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 1, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 1, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 1, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 1, voxel " << i  
            << ": Value retrieved not identical";
        pt.x += 1;
        value += 2;
        encoder.Next();
    }
    pt.y += 87;
    value += 23;
    for (int i = 0; i < 5; ++i) {
        uint16_t gotValue = encoder.Get16BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pt.x, gotPoint.x) << "Span 2, voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pt.y, gotPoint.y) << "Span 2, voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pt.z, gotPoint.z) << "Span 2, voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(value, gotValue) << "Span 2, voxel " << i  
            << ": Value retrieved not identical";
        pt.x += 1;
        value += 3;
        encoder.Next();
    }
}


TEST(VoxelEncoder, EncodeXPlane) 
{
    VoxelEncoder encoder(VoxelValue::BITS8, Slicing::X, false);
    
    VoxelPt pt;
    pt.x = 10;
    pt.y = 20;
    pt.z = 30;
    
    uint8_t value = 100;
    encoder.AppendVoxel(pt, value);
    pt.y += 1;
    value += 1;
    encoder.AppendVoxel(pt, value);
    pt.y += 1;
    value += 1;
    encoder.AppendVoxel(pt, value);

    pt.z += 3;
    pt.y += 10;
    value += 3;
    encoder.AppendVoxel(pt, value);
    
    encoder.SeekToFirst();
    EXPECT_EQ(100, encoder.Get8BitValue()) << "After seek value wrong";
    VoxelPt gotPoint;
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(10, gotPoint.x) << "After seek voxel x wrong";
    EXPECT_EQ(20, gotPoint.y) << "After seek voxel y wrong";
    EXPECT_EQ(30, gotPoint.z) << "After seek voxel z wrong";
    EXPECT_TRUE(encoder.Valid()) << "After seek invalid";

    encoder.Next();
    EXPECT_EQ(101, encoder.Get8BitValue()) << "After Next value wrong";
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(10, gotPoint.x) << "After Next voxel x wrong";
    EXPECT_EQ(21, gotPoint.y) << "After Next voxel pt wrong";
    EXPECT_TRUE(encoder.Valid()) << "After Next invalid";

    encoder.Next();
    EXPECT_EQ(102, encoder.Get8BitValue()) << "After 2nd Next value wrong";
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(22, gotPoint.y) << "After 2nd Next voxel pt wrong";
    EXPECT_TRUE(encoder.Valid()) << "After 2nd Next invalid";

    encoder.Next();
    EXPECT_EQ(105, encoder.Get8BitValue()) << "After new span, value wrong";
    encoder.GetVoxelPt(&gotPoint);
    EXPECT_EQ(10, gotPoint.x) << "After new span, voxel x wrong";
    EXPECT_EQ(32, gotPoint.y) << "After new span, voxel y wrong";
    EXPECT_EQ(33, gotPoint.z) << "After new span, voxel z wrong";
    EXPECT_TRUE(encoder.Valid()) << "After new span, invalid";

    encoder.Next();
    EXPECT_FALSE(encoder.Valid()) << "Beyond buffer is incorrectly Valid";
}

TEST(VoxelEncoder, Test8BitNormalIteration)
{
    const bool storeNormals = true;
    VoxelEncoder encoder(VoxelValue::BITS8, Slicing::Z, storeNormals);
    
    const int maxCoord = 20000;
    const int numTestPts = 1000;

    VoxelPt testPts[numTestPts];
    uint8_t testValues[numTestPts];
    Vector3d testNormals[numTestPts];

    VoxelPt currentPt;
    currentPt.x = rand() % (maxCoord - numTestPts);
    currentPt.y = rand() % maxCoord;
    currentPt.z = rand() % maxCoord;
    for (int i = 0; i < numTestPts; ++i) {
        testValues[i] = rand() % 256;
        double magnitude;
        do {
            double x = static_cast<double>(rand() % 1000);
            double y = static_cast<double>(rand() % 1000);
            double z = static_cast<double>(rand() % 1000);
            magnitude = sqrt(x*x + y*y + z*z);
            testNormals[i].x = x / magnitude;
            testNormals[i].y = y / magnitude;
            testNormals[i].z = z / magnitude;
        } while (magnitude == 0.0);
        testPts[i] = currentPt;
        encoder.AppendSurface(currentPt, testValues[i], testNormals[i]);
    }

    // Check if we get it back through iteration exactly.
    int i = 0;
    VoxelPt gotPoint;
    Vector3d gotNormal;
    for (encoder.SeekToFirst(); encoder.Valid(); encoder.Next(), ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(testPts[i].x, gotPoint.x) << "Voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(testPts[i].y, gotPoint.y) << "Voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(testPts[i].z, gotPoint.z) << "Voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(testValues[i], gotValue) << "Voxel " << i  
            << ": Value retrieved not identical";
        encoder.GetNormal(&gotNormal);
        test_vector3d(testNormals[i], gotNormal);
    }
    EXPECT_EQ(i, numTestPts) << "Number of points retrieved on iteration "
        << "is not same as appended [" << i << " vs " << numTestPts << "]";
}

TEST(ConvenienceFunctions, AppendEncoding)
{
    const bool storeNormals = true;
    VoxelEncoder encoder1(VoxelValue::BITS8, Slicing::Z, storeNormals);
    VoxelEncoder encoder2(VoxelValue::BITS8, Slicing::Z, storeNormals);
    VoxelEncoder encoderX(VoxelValue::BITS8, Slicing::X, storeNormals);
    
    const int maxCoord = 20000;
    const int numTestPts = 4;

    VoxelPt testPts[numTestPts];
    uint8_t testValues[numTestPts];
    Vector3d testNormals[numTestPts];

    // Put first half of points in encoder 1.
    VoxelPt currentPt;
    currentPt.x = rand() % (maxCoord - numTestPts);
    currentPt.y = rand() % maxCoord;
    currentPt.z = rand() % maxCoord;
    for (int i = 0; i < numTestPts / 2; ++i) {
        testValues[i] = rand() % 256;
        double magnitude;
        do {
            double x = static_cast<double>(rand() % 1000);
            double y = static_cast<double>(rand() % 1000);
            double z = static_cast<double>(rand() % 1000);
            magnitude = sqrt(x*x + y*y + z*z);
            testNormals[i].x = x / magnitude;
            testNormals[i].y = y / magnitude;
            testNormals[i].z = z / magnitude;
        } while (magnitude == 0.0);
        testPts[i] = currentPt;
        encoder1.AppendSurface(currentPt, testValues[i], testNormals[i]);
    }

    // Put second half in encoder 2.
    for (int i = numTestPts / 2; i < numTestPts; ++i) {
        testValues[i] = rand() % 256;
        double magnitude;
        do {
            double x = static_cast<double>(rand() % 1000);
            double y = static_cast<double>(rand() % 1000);
            double z = static_cast<double>(rand() % 1000);
            magnitude = sqrt(x*x + y*y + z*z);
            testNormals[i].x = x / magnitude;
            testNormals[i].y = y / magnitude;
            testNormals[i].z = z / magnitude;
        } while (magnitude == 0.0);
        testPts[i] = currentPt;
        encoder2.AppendSurface(currentPt, testValues[i], testNormals[i]);
        encoderX.AppendSurface(currentPt, testValues[i], testNormals[i]);
    }

    // Append encoder 2 results (or what we have loaded) into encoder 1.
    string encoder1Data = encoder1.GetEncoding();
    string encodedData = encoder1Data;
    string toAppendData = encoder2.GetEncoding();

    EXPECT_NO_THROW({
        AppendEncoding(toAppendData, &encodedData);
    });

    encoder1.SetEncoding(encodedData);

    // Make sure combined result is what we get through iteration.
    int i = 0;
    VoxelPt gotPoint;
    Vector3d gotNormal;
    for (encoder1.SeekToFirst(); encoder1.Valid(); encoder1.Next(), ++i) {
        uint8_t gotValue = encoder1.Get8BitValue();
        encoder1.GetVoxelPt(&gotPoint);
        EXPECT_EQ(testPts[i].x, gotPoint.x) << "Voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(testPts[i].y, gotPoint.y) << "Voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(testPts[i].z, gotPoint.z) << "Voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(testValues[i], gotValue) << "Voxel " << i  
            << ": Value retrieved not identical";
        encoder1.GetNormal(&gotNormal);
        test_vector3d(testNormals[i], gotNormal);
    }
    EXPECT_EQ(i, numTestPts) << "Number of points retrieved on iteration "
        << "is not same as appended [" << i << " vs " << numTestPts << "]";

    // Make sure we throw exception if flag byte is different
    EXPECT_THROW({
        AppendEncoding(encoderX.GetEncoding(), &encoder1Data);
    }, std::invalid_argument);
}


TEST(VoxelEncoder, AppendEncoding)
{
    const bool storeNormals = true;
    VoxelEncoder encoder1(VoxelValue::BITS8, Slicing::Z, storeNormals);
    VoxelEncoder encoder2(VoxelValue::BITS8, Slicing::Z, storeNormals);
    VoxelEncoder encoderX(VoxelValue::BITS8, Slicing::X, storeNormals);
    
    const int maxCoord = 20000;
    const int numTestPts = 1000;

    VoxelPt testPts[numTestPts];
    uint8_t testValues[numTestPts];
    Vector3d testNormals[numTestPts];

    // Put first half of points in encoder 1.
    VoxelPt currentPt;
    currentPt.x = rand() % (maxCoord - numTestPts);
    currentPt.y = rand() % maxCoord;
    currentPt.z = rand() % maxCoord;
    for (int i = 0; i < numTestPts / 2; ++i) {
        testValues[i] = rand() % 256;

        double magnitude;
        do {
            double x = static_cast<double>(rand() % 1000);
            double y = static_cast<double>(rand() % 1000);
            double z = static_cast<double>(rand() % 1000);
            magnitude = sqrt(x*x + y*y + z*z);
            testNormals[i].x = x / magnitude;
            testNormals[i].y = y / magnitude;
            testNormals[i].z = z / magnitude;
        } while (magnitude == 0.0);
        testPts[i] = currentPt;
        encoder1.AppendSurface(currentPt, testValues[i], testNormals[i]);
    }

    // Put second half in encoder 2.
    for (int i = numTestPts / 2; i < numTestPts; ++i) {
        testValues[i] = rand() % 256;

        double magnitude;
        do {
            double x = static_cast<double>(rand() % 1000);
            double y = static_cast<double>(rand() % 1000);
            double z = static_cast<double>(rand() % 1000);
            magnitude = sqrt(x*x + y*y + z*z);
            testNormals[i].x = x / magnitude;
            testNormals[i].y = y / magnitude;
            testNormals[i].z = z / magnitude;
        } while (magnitude == 0.0);
        testPts[i] = currentPt;
        encoder2.AppendSurface(currentPt, testValues[i], testNormals[i]);
        encoderX.AppendSurface(currentPt, testValues[i], testNormals[i]);
    }

    // Append encoder 2 results (or what we have loaded) into encoder 1.
    EXPECT_NO_THROW({
        encoder1.AppendEncoding(encoder2.GetEncoding());
    });

    // Make sure combined result is what we get through iteration.
    int i = 0;
    VoxelPt gotPoint;
    Vector3d gotNormal;
    for (encoder1.SeekToFirst(); encoder1.Valid(); encoder1.Next(), ++i) {
        uint8_t gotValue = encoder1.Get8BitValue();
        encoder1.GetVoxelPt(&gotPoint);
        EXPECT_EQ(testPts[i].x, gotPoint.x) << "Voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(testPts[i].y, gotPoint.y) << "Voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(testPts[i].z, gotPoint.z) << "Voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(testValues[i], gotValue) << "Voxel " << i  
            << ": Value retrieved not identical";
        encoder1.GetNormal(&gotNormal);
        test_vector3d(testNormals[i], gotNormal);
    }
    EXPECT_EQ(i, numTestPts) << "Number of points retrieved on iteration "
        << "is not same as appended [" << i << " vs " << numTestPts << "]";

    // Make sure we throw exception if flag byte is different
    EXPECT_THROW({
        encoder1.AppendEncoding(encoderX.GetEncoding());
    }, std::invalid_argument);
}


// To run this time consuming test, 
// you can use the --gtest_also_run_disabled_tests flag
TEST(VoxelEncoder, DISABLED_MaxBodySizeTest)
{
    const bool storeNormals = true;
    VoxelEncoder encoder(VoxelValue::BITS8, Slicing::Z, storeNormals);
    
    const int million = 1000000;
    const int numMillion = 150;
    const int numTestPts = numMillion * million;

    const int spanFreq = 50;
    const int sliceFreq = numTestPts / 1000;
    const int maxCoord = 20000;

    cout << "Allocating " << numMillion << " million test points" 
         << endl << flush;

    VoxelPt *pPts = new VoxelPt[numTestPts];
    uint8_t *pValues = new uint8_t[numTestPts];
    Vector3d *pNormals = new Vector3d[numTestPts];

    cout << "Testing ability to store and retrieve " << numMillion
         << " million voxels" << endl << flush;


    VoxelPt currentPt;
    currentPt.x = rand() % maxCoord;
    currentPt.y = rand() % maxCoord;
    currentPt.z = rand() % maxCoord;
    for (int i = 0; i < numTestPts; ++i) {
        pValues[i] = rand() % 256;

        double magnitude;
        do {
            double x = static_cast<double>(rand() % 1000);
            double y = static_cast<double>(rand() % 1000);
            double z = static_cast<double>(rand() % 1000);
            magnitude = sqrt(x*x + y*y + z*z);
            pNormals[i].x = x / magnitude;
            pNormals[i].y = y / magnitude;
            pNormals[i].z = z / magnitude;
        } while (magnitude == 0.0);

        if (rand() % sliceFreq == 0) {
            currentPt.z = (currentPt.z + 1) % maxCoord;
            currentPt.y = rand() % maxCoord;
            currentPt.x = rand() % maxCoord;
        } else if (rand() % spanFreq == 0) {
            currentPt.y = (currentPt.y + 1) % maxCoord;
            currentPt.x = rand() % maxCoord;
        } else {
            currentPt.x += 1;
        }
        if (currentPt.x >= maxCoord) {
            currentPt.y = (currentPt.y + 1) % maxCoord;
            currentPt.x = rand() % maxCoord;
        }
        pPts[i] = currentPt;
        encoder.AppendSurface(currentPt, pValues[i], pNormals[i]);
    }

    // Check if we get it back.
    VoxelPt gotPoint;
    Vector3d gotNormal;
    encoder.SeekToFirst();
    for (int i = 0; i < numTestPts; ++i) {
        uint8_t gotValue = encoder.Get8BitValue();
        encoder.GetVoxelPt(&gotPoint);
        EXPECT_EQ(pPts[i].x, gotPoint.x) << "Voxel " << i 
            << ": Voxel x retrieved not identical";
        EXPECT_EQ(pPts[i].y, gotPoint.y) << "Voxel " << i 
            << ": Voxel y retrieved not identical";
        EXPECT_EQ(pPts[i].z, gotPoint.z) << "Voxel " << i  
            << ": Voxel z retrieved not identical";
        EXPECT_EQ(pValues[i], gotValue) << "Voxel " << i  
            << ": Value retrieved not identical";
        encoder.GetNormal(&gotNormal);
        test_vector3d(pNormals[i], gotNormal);
        encoder.Next();
    }

    delete [] pNormals;
    delete [] pValues;
    delete [] pPts;
}


int main(int argc, char **argv) 
{
    string testString;
    std::cout << "Maximum size of string: " 
              << testString.max_size() / 1000000 << " MChar" << std::endl;
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}


