/**
 * EM Voxel Data Types
 * Copyright 2012 HHMI.  All rights reserved.
 *
 * Bill Katz (katzw@janelia.hhmi.org)
 *
 * This file specifies data needed for interior/surface voxels and
 * managing lists of voxels.
 */

namespace cpp emdata
namespace java emdata

include "basetypes.thrift"

// Flags for data stored in voxels within voxel list

enum VoxelValue {
    BITS8 = 0,
    BITS16 = 1
}

enum VoxelNormal {
    ENCODED = 0,
    HALF3 = 1,
    FLOAT3 = 2
}

enum Slicing {
    Z = 0,
    Y = 1,
    X = 2
}

// VoxelLists contain interior (and possibly surface) voxels
// in a packed format within the encodedData string.
// These strings are packed like this:
//
//   Byte   Content
//   0      Flag byte
//   1-2    Primary slicing coordinate (usually Z)
//   3-6    i32 value of # of spans in this slice
//   7-8    Secondary slice coordinate
//   9-10   Third slice coordinate
//   11-12  # of voxels for this span
//   13+    Repeating voxel data of form:
//             1 or 2 byte grayscale value
//             optional 2 byte normal or magnitude
//
// Multiple slices can be contained within encodedData by
// repeating bytes 1-13+.  You can concatenate multiple
// encodedData by just appending all but the first byte
// of a second encoded string.  This assumes the appended
// data follow the same flags (value type, slicing direction,
// and whether normals/magnitudes are stored).
//
// Please see the VoxelEncoder class for code that can
// generate encoded data from a stream of voxel points as
// well as decode encoded data.
//
// The 2 byte normal/magnitude is encoded by a 16-bit value:
//    Most significant bit = surface bit
//    Least significant 15 bits:
//        phi (7 bits), lambda (8 bits) of normal OR
//        gradient magnitude for volume rendering

struct VoxelList {
    1:  VoxelValue          valueType,
    2:  Slicing             slicingType,
    3:  bool                normalStored,
    4:  i32                 numVoxels,
    5:  i32                 numSurfaceVoxels,
    6:  basetypes.Vector3d  resolution,
    7:  basetypes.Bounds3d  bounds,
    8:  string              encodedData,
    9:  optional basetypes.Color color,
    10: optional string     comment
    11: optional basetypes.KeyValues keyValues
}

typedef map<basetypes.LabelId, VoxelList> VoxelListMapData

struct VoxelListMap {
    1:  i32 numBodies,
    2:  VoxelListMapData data
}

// Normals Table
// Values from 0 to 0x7FFF where top 15-bits are phi
// and bottom 16-bits are lambda

struct NormalsTable {
    1:  list<basetypes.Vector3d>  normals;
}
