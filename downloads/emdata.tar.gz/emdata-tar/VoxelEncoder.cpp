// Copyright 2012 HHMI.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of HHMI nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: katzw@janelia.hhmi.org (Bill Katz)
//  Written as part of the FlyEM Project at Janelia Farm Research Center.

#include <string>
#include <iostream>
#include <stdexcept>
#include <math.h>

#include <boost/shared_ptr.hpp>
#include <boost/lexical_cast.hpp>

#include <transport/TTransportUtils.h>
#include <transport/TFileTransport.h>
#include <transport/TSimpleFileTransport.h>
#include <protocol/TBinaryProtocol.h>
//#include <protocol/TDenseProtocol.h>   -- Experimental so don't use.
//#include <protocol/TCompactProtocol.h> -- Fails on Mac due to right shift error

#include "VoxelEncoder.h"
#include "emdata.h"

using std::string;
using std::cout;
using std::cerr;
using std::endl;
using std::ostringstream;

using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

namespace emdata {

// Convenience functions

string EncodingStyle(const string& encodedData)
{
    std::ostringstream ss;

    unsigned char flags = encodedData[0];
    if (flags & 0x01) {
        ss << "16 bit values, ";
    } else {
        ss << "8 bit values, ";
    }
    switch ((Slicing::type)((flags & 0x06) >> 1)) {
        case Slicing::Z:
            ss << "Z slices, ";
            break;
        case Slicing::Y:
            ss << "Y slices, ";
            break;
        case Slicing::X:
            ss << "X slices, ";
            break;
    }
    if (flags & 0x08) {
        ss << "and normals stored.";
    } else {
        ss << "and normals not stored.";
    }
    return ss.str();
}

void AppendEncoding(const string& encodedData, string *concatenatedEncodings)
{
    // Check flag byte to make sure the two encodings are compatible
    if (encodedData[0] != (*concatenatedEncodings)[0]) {
        std::ostringstream description;
        description << "Encoding to be concatenated must have same voxel "
                    << "values, slicing direction, and normal storage."
                    << endl;
        description << "Data to be appended was encoded as:" << endl;
        description << EncodingStyle(encodedData) << endl;
        description << "Compared to target encoding:" << endl;
        description << EncodingStyle(*concatenatedEncodings) << endl;
        throw std::invalid_argument(description.str().c_str());
    }

    // Given encoding format, concat are truly append minus flag byte.
    concatenatedEncodings->append(encodedData.data()+1, encodedData.size()-1);
}


/*
    Discussion of this encoder's architecture:

    It's a state machine that can at any time both (1) accept data
    that you want to encode, or (2) act as an iterator that lets
    you read data.  Because of this dual nature, you should chunk
    the class members into two separate categories: those that
    let you read/iterate and those that let you encode/write.
*/

//
// Public methods
//

VoxelEncoder::VoxelEncoder(VoxelValue::type valueType, Slicing::type sliceType,
                           bool normalStored, NormalsTable* pNormalsTable,
                           bool debug)
{
    valueType_ = valueType;
    sliceType_ = sliceType;
    normalStored_ = normalStored;
    pNormalsTable_ = pNormalsTable;
    debug_ = debug;

    ClearEncoding();
}

void VoxelEncoder::ClearEncoding()
{
    decodeNormals_ = false;
    
    curLocation_ = 0;
    spansRemaining_ = 0;
    spansRead_ = 0;
    voxelsRemaining_ = 0;
    voxelsRead_ = 0;

    curValid_ = false;

    data_.clear();
    spanBuffer_.clear();
    spanBufferVoxels_ = 0;
    sliceBuffer_.clear();
    sliceBufferSpans_ = 0;

    spansEncoded_ = 0;
    voxelsEncoded_ = 0;
    boundsUncomputed_ = true;
    SetFlagsByte();
}

void VoxelEncoder::SetEncoding(const string& encodedData)
{
    ClearEncoding();

    data_ = encodedData;
    ReadFlagsByte();
    SeekToFirst();
}

void VoxelEncoder::AppendEncoding(const string& encodedData)
{
    // Check flag byte to make sure the two encodings are compatible
    if (data_[0] != encodedData[0]) {
        std::ostringstream description;
        description << "Encoding to be concatenated must have same voxel "
                    << "values, slicing direction, and normal storage."
                    << endl;
        description << "Data to be appended was encoded as:" << endl;
        description << EncodingStyle(encodedData) << endl;
        description << "Compared to target encoding:" << endl;
        description << EncodingStyle(data_) << endl;
        throw std::invalid_argument(description.str().c_str());
    }

    // Given encoding format, appends are truly appends minus flag byte.
    AppendCurrentSlice();
    data_.append(encodedData.data()+1, encodedData.size()-1);
}


string& VoxelEncoder::GetEncoding()
{
    AppendCurrentSlice();
    return data_;
}

//
// Iteration support.  Any of these methods will force incomplete spans
// or slices to be added to main data string.
//
void VoxelEncoder::SeekToFirst()
{
    AppendCurrentSlice();
    ResetHead();
    Next();     // Read the first
    if (debug_) {
        cout << "After SeekToFirst(), curLocation_ = " << curLocation_ << endl;
    }
}

bool VoxelEncoder::Valid()
{
    return curValid_;
}

void VoxelEncoder::Next(const bool decodeNormals)
{
    AppendCurrentSlice();
    if (curLocation_ < data_.size()) {
        if (curLocation_ == 0) {
            ReadFlagsByte();
        }
        if (spansRemaining_ == 0) {
            ReadSliceHeader();
        }
        if (voxelsRemaining_ == 0) {
            ReadSpanHeader();
        }
        if (debug_) {
            cout << "Next(): ";
        }
        ReadValue(decodeNormals);
        curValid_ = true;
    } else {
        curValid_ = false;
        if (debug_) {
            cout << "Next(): called at end of buffer, curLocation_ = " 
                 << curLocation_ << endl;
        }
    }
}

//
// Simple Getters for most recently read voxel
//

void VoxelEncoder::GetVoxelPt(VoxelPt *pPoint)
{
    pPoint->x = curPt_.x;
    pPoint->y = curPt_.y;
    pPoint->z = curPt_.z;
}

uint8_t VoxelEncoder::Get8BitValue()
{
    if (valueType_ == VoxelValue::BITS16) {
        throw std::domain_error(
            "Cannot retrieve 8 bit value when encoder set to 16 bit values");
    }
    return cur8bitValue_;
}

uint16_t VoxelEncoder::Get16BitValue()
{
    if (valueType_ == VoxelValue::BITS8) {
        throw std::domain_error(
            "Cannot retrieve 16 bit value when encoder set to 8 bit values");
    }
    return cur16bitValue_;
}

bool VoxelEncoder::IsSurface()
{
    return curIsSurface_;
}

void VoxelEncoder::GetNormal(Vector3d *pNormal)
{
    if (!decodeNormals_) {
        throw std::domain_error(
            "Cannot ask for normals when asking to not decode normals");
    }
    pNormal->x = curNormal_.x;
    pNormal->y = curNormal_.y;
    pNormal->z = curNormal_.z;
}

uint16_t VoxelEncoder::GetEncodedNormal()
{
    return curEncodedNormal_ & LARGEST_15BITS;
}

double VoxelEncoder::GetMagnitude()
{
    return curMagnitude_;
}

//
// Routines for adding to encoding
//

void VoxelEncoder::AppendVoxel(const VoxelPt& pt, const uint8_t value)
{
    CheckSpan(pt);
    spanBuffer_.append(1, value);
    spanBufferVoxels_ += 1;
    if (debug_) {
        cout << "AppendVoxel: " << pt_to_string(pt)
             << " value = " << (int)(value) 
             << " (current span " << spanBufferVoxels_ 
             << " voxels)" << endl;
    }
}

void VoxelEncoder::AppendVoxel(const VoxelPt& pt, const uint16_t value)
{
    CheckSpan(pt);
    spanBuffer_.append((const char*)(&value), 2);
    spanBufferVoxels_ += 1;
}

void VoxelEncoder::AppendSurface(const VoxelPt& pt, const uint8_t value,
                                 const Vector3d& normal)
{
    CheckSpan(pt);
    spanBuffer_.append(1, value);
    uint16_t normalBytes = EncodeNormal(normal) | MOST_SIGNIFICANT_16BIT;
    spanBuffer_.append((const char*)(&normalBytes), 2);
    spanBufferVoxels_ += 1;
}

void VoxelEncoder::AppendSurface(const VoxelPt& pt, const uint16_t value,
                                 const Vector3d& normal)
{
    CheckSpan(pt);
    spanBuffer_.append((const char*)(&value), 2);
    uint16_t normalBytes = EncodeNormal(normal) | MOST_SIGNIFICANT_16BIT;
    spanBuffer_.append((const char*)(&normalBytes), 2);
    spanBufferVoxels_ += 1;
}

void VoxelEncoder::AppendInterior(const VoxelPt& pt, const uint8_t value,
                                  const double magnitude)
{
    CheckSpan(pt);
    spanBuffer_.append(1, value);
    uint16_t bytes = std::min(0x7FFF, std::max(0, static_cast<int>(magnitude)));
    spanBuffer_.append((const char*)(&bytes), 2);
    spanBufferVoxels_ += 1;
}

void VoxelEncoder::AppendInterior(const VoxelPt& pt, const uint16_t value,
                                  const double magnitude)
{
    CheckSpan(pt);
    spanBuffer_.append((const char*)(&value), 2);
    uint16_t bytes = std::min(0x7FFF, std::max(0, static_cast<int>(magnitude)));
    spanBuffer_.append((const char*)(&bytes), 2);
    spanBufferVoxels_ += 1;
}


//
// Private methods
//

void VoxelEncoder::SetFlagsByte()
{
    if (valueType_ == VoxelValue::BITS8) {
        valueSize_ = 3;         // 2 byte normal/magnitude + 1 byte value
    } else {
        valueSize_ = 4;         // 2 byte normal/magnitude + 2 byte value
    }

    // Append the flags char
    unsigned char flags = 0;
    flags |= (normalStored_ ? 1 : 0);
    flags <<= 2;
    flags |= (0x03 & sliceType_);
    flags <<= 1;
    flags |= (0x01 & valueType_);
    data_.append(1, flags);
}

void VoxelEncoder::ReadFlagsByte()
{
    unsigned char flags = data_[0];
    normalStored_ = (flags & 0x08) ? true : false;
    sliceType_ = (Slicing::type)((flags & 0x06) >> 1);
    if (flags & 0x01) {
        valueType_ = VoxelValue::BITS16;
    } else {
        valueType_ = VoxelValue::BITS8;
    }
    curLocation_ = 1;
}

void VoxelEncoder::ReadSliceHeader()
{
    uint16_t slice = Get16Bit(curLocation_);
    switch (sliceType_) {
        case Slicing::Z:
            curPt_.z = slice;
            break;
        case Slicing::Y:
            curPt_.y = slice;
            break;
        case Slicing::X:
            curPt_.x = slice;
    }
    spansRemaining_ = Get32Bit(curLocation_+2);
    spansRead_ = 0;
    curLocation_ += SLICE_HEADER_SIZE;

    if (debug_) {
        cout << "ReadSliceHeader() -- set current slice to "
             << slice << " with " << spansRemaining_ 
             << " spans remaining" << endl;
    }
}

void VoxelEncoder::ReadSpanHeader()
{
    switch (sliceType_) {
        case Slicing::Z:
            curPt_.y = Get16Bit(curLocation_);
            curPt_.x = Get16Bit(curLocation_+2);
            break;
        case Slicing::Y:
            curPt_.z = Get16Bit(curLocation_);
            curPt_.x = Get16Bit(curLocation_+2);
            break;
        case Slicing::X:
            curPt_.z = Get16Bit(curLocation_);
            curPt_.y = Get16Bit(curLocation_+2);
    }
    voxelsRemaining_ = Get16Bit(curLocation_+4);
    voxelsRead_ = 0;
    curLocation_ += SPAN_HEADER_SIZE;

    if (debug_) {
        cout << "ReadSpanHeader() -- set current pt @ "
             << pt_to_string(curPt_) 
             << " with " << voxelsRemaining_ 
             << " voxels remaining" << endl;
    }
}

void VoxelEncoder::ReadNormal(const uint16_t buffer)
{
    uint16_t value = buffer & LARGEST_15BITS;
    if (pNormalsTable_) {
        curNormal_ = pNormalsTable_->normals[value];
        if (debug_) {
            cout << "ReadNormal: using lookup buffer" << endl;
            cout << "   value: " << value << endl;
            cout << "       x: " << curNormal_.x << endl;
            cout << "       y: " << curNormal_.y << endl;
            cout << "       z: " << curNormal_.z << endl;
        }
    } else {
        double phi = ((value >> 8) - 64) * PHI_INCR;
        double lambda = ((value & 0x00FF) - 128) * LAMBDA_INCR;
        curNormal_.x = cos(lambda) * cos(phi);
        curNormal_.y = sin(lambda) * cos(phi);
        curNormal_.z = sin(phi);
        if (debug_) {
            cout << "ReadNormal: " << endl;
            cout << "  lambda: " << lambda << endl;
            cout << "     phi: " << phi << endl;
            cout << "       x: " << curNormal_.x << endl;
            cout << "       y: " << curNormal_.y << endl;
            cout << "       z: " << curNormal_.z << endl;
        }
    }
}

void VoxelEncoder::ReadValue(const bool decodeNormals)
{
    decodeNormals_ = decodeNormals;
    if (valueType_ == VoxelValue::BITS8) {
        cur8bitValue_ = static_cast<uint8_t>(data_[curLocation_]);
        curLocation_ += 1;
    } else {
        cur16bitValue_ = Get16Bit(curLocation_);
        curLocation_ += 2;
    }
    if (normalStored_) {
        uint16_t buffer = Get16Bit(curLocation_);
        curLocation_ += 2;
        curIsSurface_ = buffer & MOST_SIGNIFICANT_16BIT;
        curEncodedNormal_ = buffer;
        if (curIsSurface_ && decodeNormals) {
            ReadNormal(buffer);
        } else {
            curMagnitude_ = static_cast<double>(buffer);
        }
    }
    if (voxelsRead_) {
        // Advance the implicit coordinate.
        switch (sliceType_) {
            case Slicing::Z:
            case Slicing::Y:
                curPt_.x += 1;
                break;
            case Slicing::X:
                curPt_.y += 1;
                break;
        }
    }
    --voxelsRemaining_;
    ++voxelsRead_;

    if (voxelsRemaining_ == 0) {
        --spansRemaining_;
        ++spansRead_;
    }

    if (debug_) {
        int value;
        if (valueType_ == VoxelValue::BITS8)
            value = cur8bitValue_;
        else
            value = cur16bitValue_;
        cout << "ReadValue " << value << " @ " << pt_to_string(curPt_)
             << ": read " << voxelsRead_ << " of "
             << voxelsRead_ + voxelsRemaining_ << " voxels"<< endl;
    }
}

void VoxelEncoder::ResetHead()
{
    curLocation_ = 0;
    spansRemaining_ = 0;
    spansRead_ = 0;
    voxelsRemaining_ = 0;
    voxelsRead_ = 0;
    curValid_ = false;
    decodeNormals_ = false;
}

// Low-level routines that get around unsigned/signed issues by moving bits
uint16_t VoxelEncoder::Get16Bit(int dataPosition)
{
    uint16_t buffer;
    memcpy(&buffer, data_.data() + dataPosition, 2);
    return buffer;
}

uint32_t VoxelEncoder::Get32Bit(int dataPosition)
{
    uint32_t buffer;
    memcpy(&buffer, data_.data() + dataPosition, 4);
    return buffer;
}

bool VoxelEncoder::IsNewSlice(const VoxelPt& pt)
{
    switch (sliceType_) {
        case Slicing::Z:
            if (pt.z != lastPt_.z) {
                if (debug_) {
                    cout << "New slice detected:" << pt_to_string(lastPt_)
                         << " to " << pt_to_string(pt) << endl;
                }
                return true;
            }
            break;
        case Slicing::Y:
            if (pt.y != lastPt_.y) {
                if (debug_) {
                    cout << "New slice detected:" << pt_to_string(lastPt_)
                         << " to " << pt_to_string(pt) << endl;
                }
                return true;
            }
            break;
        case Slicing::X:
            if (pt.x != lastPt_.x) {
                if (debug_) {
                    cout << "New slice detected:" << pt_to_string(lastPt_)
                         << " to " << pt_to_string(pt) << endl;
                }
                return true;
            }
            break;
    }
    return false;
}

bool VoxelEncoder::IsNewSpan(const VoxelPt& pt)
{
    switch (sliceType_) {
        case Slicing::Z:
            if (pt.x != lastPt_.x + 1 || pt.y != lastPt_.y) {
                if (debug_) {
                    cout << "New span detected in Z slice:" 
                         << pt_to_string(lastPt_)
                         << " to " << pt_to_string(pt) << endl;
                }
                return true;
            }
            break;
        case Slicing::Y:
            if (pt.x != lastPt_.x + 1 || pt.z != lastPt_.z) {
                if (debug_) {
                    cout << "New span detected in Y slice:" 
                         << pt_to_string(lastPt_)
                         << " to " << pt_to_string(pt) << endl;
                }
                return true;
            }
            break;
        case Slicing::X:
            if (pt.y != lastPt_.y + 1 || pt.z != lastPt_.z) {
                if (debug_) {
                    cout << "New span detected in X slice:" 
                         << pt_to_string(lastPt_)
                         << " to " << pt_to_string(pt) << endl;
                }
                return true;
            }
            break;
    }
    return false;
}

void VoxelEncoder::CheckSpan(const VoxelPt& pt)
{
    if (spanBufferVoxels_ > 0) {
        if (IsNewSlice(pt)) {
            AppendCurrentSlice();
            startPt_ = pt;
        } else if (IsNewSpan(pt)) {
            AppendCurrentSpan();
            startPt_ = pt;
        }
    } else {
        startPt_ = pt;
    }
    lastPt_ = pt;
}

void VoxelEncoder::AppendCurrentSlice()
{
    AppendCurrentSpan();
    if (sliceBuffer_.empty()) {
        return;
    }
    if (debug_) {
        cout << "Appending current slice (" << sliceBufferSpans_
             << " spans) starting from data_ pos = "
             << data_.size() << endl;
        cout << "Before append, " << sliceBufferSpans_ << " spans were "
             << "encoded in this slice" << endl;
    }
    switch (sliceType_) {
        case Slicing::Z:
            Append16Bit(startPt_.z, &data_);
            break;
        case Slicing::Y:
            Append16Bit(startPt_.y, &data_);
            break;
        case Slicing::X:
            Append16Bit(startPt_.x, &data_);
            break;
    }
    Append32Bit(sliceBufferSpans_, &data_);
    data_.append(sliceBuffer_);
    spansEncoded_ += sliceBufferSpans_;

    // Reset our current span
    sliceBuffer_.clear();
    sliceBufferSpans_ = 0;
}


void VoxelEncoder::AppendCurrentSpan()
{
    if (spanBuffer_.empty()) {
        return;
    }
    if (debug_) {
        cout << "Appending current span (" << spanBufferVoxels_
             << ") starting from sliceBuffer_ pos = "
             << sliceBuffer_.size() << endl;
        cout << "Before append, " << spanBufferVoxels_ 
             << " voxels were encoded" << endl;
    }
    switch (sliceType_) {
        case Slicing::Z:
            Append16Bit(startPt_.y, &sliceBuffer_);
            Append16Bit(startPt_.x, &sliceBuffer_);
            break;
        case Slicing::Y:
            Append16Bit(startPt_.z, &sliceBuffer_);
            Append16Bit(startPt_.x, &sliceBuffer_);
            break;
        case Slicing::X:
            Append16Bit(startPt_.z, &sliceBuffer_);
            Append16Bit(startPt_.y, &sliceBuffer_);
            break;
    }
    Append16Bit(spanBufferVoxels_, &sliceBuffer_);
    sliceBuffer_.append(spanBuffer_);
    sliceBufferSpans_ += 1;
    voxelsEncoded_ += spanBufferVoxels_;

    // Reset our current span
    spanBuffer_.clear();
    spanBufferVoxels_ = 0;
}

uint16_t VoxelEncoder::EncodeNormal(const Vector3d& normal)
{
    // Convert to vector # using spherical coords lambda & phi.
    // See: Digital Cartography for Computer Graphics
    //      Graphics Gems, pp. 307-320.
    double lambda;
    if (normal.x == 0.0 && normal.y == 0.0)
        lambda = 0.0;
    else
        lambda = atan2(normal.y, normal.x);
    double phi = asin(normal.z);

    int l = static_cast<int>(
        floor((lambda + LAMBDA_HALF_INCR) / LAMBDA_INCR)) + 128;
    int p = static_cast<int>(
        floor((phi + PHI_HALF_INCR) / PHI_INCR)) + 64;
    uint16_t lBytes = std::max(0, std::min(l, 255));
    uint16_t pBytes = std::max(0, std::min(p, 127));
    uint16_t bytes = pBytes << 8 | lBytes;

    if (debug_) {
        cout << "EncodeNormal: " << endl;
        cout << "       x: " << normal.x << endl;
        cout << "       y: " << normal.y << endl;
        cout << "       z: " << normal.z << endl;
        cout << "  lambda: " << lambda << endl;
        cout << "     phi: " << phi << endl;
        cout << "  lbytes: " << lBytes << endl;
        cout << "  pbytes: " << pBytes << endl;
        cout << "   bytes: " << bytes << endl;
    }
    return bytes;
}

// Low-level routines that get around unsigned/signed issues by moving bits
void VoxelEncoder::Append16Bit(const uint16_t buffer, string *pBuffer)
{
    pBuffer->append((const char*)(&(buffer)), 2);
}

void VoxelEncoder::Append32Bit(const uint32_t buffer, string *pBuffer)
{
    pBuffer->append((const char*)(&(buffer)), 4);
}



} // emdata namespace
