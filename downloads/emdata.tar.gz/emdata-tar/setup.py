from setuptools import setup

setup(name = "emdata",
    version = "0.1",
    url = "http://github.com/janelia-flyem/emdata",
    description = "FlyEM data handling using Apache Thrift and homegrown voxel encoding data structures.",
    author = "William Katz",
    author_email = 'katzw@janelia.hhmi.org',
    packages = ['emdata', 'emdata.basetypes', 'emdata.labels', 'emdata.voxels', 'emdata.analysis'],
    package_data = { },
    install_requires = [ ],
    scripts = []
)
