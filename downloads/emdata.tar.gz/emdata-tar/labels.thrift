/**
 * EM Label Data
 * Copyright 2012 HHMI.  All rights reserved.
 *
 * Bill Katz (katzw@janelia.hhmi.org)
 *
 * This file specifies data used to manage labels for FlyEM volumes
 */

/**
 * Thrift files can specify namespaces or packages in various target languages
 */
namespace cpp emdata
namespace java emdata

include "basetypes.thrift"

typedef basetypes.LabelId   AtomId          // Atoms are the smallest regions, e.g. watershed regions.
typedef basetypes.LabelId   SupervoxelId    // These are the smallest regions visible to users.
typedef basetypes.LabelId   BodyId

typedef set<basetypes.LabelId>  LabelSetData
typedef map<basetypes.LabelId, basetypes.LabelId>   LabelMapData

const AtomId        EDGE_ATOM = 0
const SupervoxelId  EDGE_SUPERPIXEL = 0
const SupervoxelId  MIXED_SUPERPIXEL = -1   // "Mixed" = more than one label
const BodyId        EDGE_BODY = 0
const BodyId        MIXED_BODY = -1

enum LabelType {
    ATOM = 0,
    SUPERVOXEL,
    SEGMENT,
    BODY
}

enum BodyType {
    ANCHOR = 1,
    ORPHAN,
    LEAVES
}


struct BodyInfo {
    1:  BodyId              bodyId,
    2:  i16                 boiId,
    3:  string              name,
    4:  string              cellType,
    5:  string              location,
    6:  basetypes.Vector3d  resolution,
    7:  basetypes.Bounds3d  bounds,
    8:  i32                 numVoxels,
    9:  i32                 numSurfaceVoxels,
    10: basetypes.VoxelCoord numSlices,
    11: optional bool       corrected,
    12: optional BodyType   bodyType,
    13: optional string     comment,
    14: optional basetypes.KeyValues keyValues
}

struct LabelSet {
    1:  LabelType           setType,
    2:  LabelSetData        data
}
 
struct LabelMap {
    1:  LabelType               mapFromType,
    2:  LabelType               mapToType,
    3:  LabelMapData            data,
    4:  optional LabelSetData   loi   // Labels of interest
}
