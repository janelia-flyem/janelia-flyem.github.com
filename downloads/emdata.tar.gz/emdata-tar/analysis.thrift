/**
 * EM Analysis Data
 * Copyright 2012 HHMI.  All rights reserved.
 *
 * Bill Katz (katzw@janelia.hhmi.org)
 *
 * This file specifies the data used for analyzing the EM segmentation.
 */

namespace cpp emdata
namespace java emdata

include "basetypes.thrift"
include "labels.thrift"


/**
 * Annotations
 */
struct TBar {
    1:  basetypes.VoxelPt     location,
    2:  basetypes.Confidence  confidence
}

struct Postsyn {
    1:  basetypes.VoxelPt     location,
    2:  basetypes.Confidence  confidence
}

/**
 * Per slice synapse-driven tracing data
 */

const string GROUND_TRUTH = "groundtruth"
const string ANCHOR_STACK = "anchorstack"
 
struct TracingSession {
    1:  string  agent_id,       // Can be userid or constants above
    2:  string  session_hash,
    3:  string  session_path,
    4:  string  base_session_hash,
    5:  string  base_session_path,
    6:  basetypes.Bounds3d  bounds
}

struct PostsynBodies {
    1:  TracingSession      session,
    2:  set<labels.BodyId>  bodies_of_interest
}

struct PointData {
    1:  basetypes.VoxelPt   location,
    2:  labels.BodyId       body_id
}

struct PointsOfInterest {
    1:  TracingSession      session,
    2:  list<PointData>     point_data
}

struct PostsynSite {
    1:  basetypes.VoxelPt   postsyn,
    2:  basetypes.VoxelPt   tbar,
    3:  labels.BodyId       postsyn_body_id
}

struct TracingAssignment {
    1:  TracingSession      session,
    2:  list<PostsynSite>   postsyn_sites   // Should be ordered x, then y, then z
}

// Note that TracingPerSlice can only have one anchorstack.
struct TracingPerSlice {
    1:  i16         z,
    2:  map<string, TracingAssignment> assignments  // Should include "anchorstack"
}

// Tracings on synapses
struct SynapseTrace {
    1:  labels.BodyId       presyn_body_id,
    2:  labels.BodyId       postsyn_body_id,
    3:  string              agent_id,
    4:  string              session_path
}
struct SynapseTracing {
    1:  basetypes.VoxelPt   postsyn,
    2:  basetypes.VoxelPt   tbar,
    3:  list<SynapseTrace>  traces;
}
struct SynapsesTracing {
    1:  map<string, TracingSession> session_index
    2:  list<SynapseTracing>        tracings;
}

typedef map<labels.BodyId, i64> BodyToNumberMap
typedef BodyToNumberMap         BodyOverlapMap

struct BodyOverlaps {
    1:  TracingSession  session1,
    2:  TracingSession  session2,
    3:  map<labels.BodyId,BodyOverlapMap> overlap_map;
}

struct SessionStats {
    1:  TracingSession  session
    2:  BodyToNumberMap body_volumes
}

