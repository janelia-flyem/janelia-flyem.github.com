// Copyright 2012 HHMI.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of HHMI nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: katzw@janelia.hhmi.org (Bill Katz)
//  Written as part of the FlyEM Project at Janelia Farm Research Center.

#ifndef __VOXELENCODER_H__
#define __VOXELENCODER_H__

#include <string>

#include <emdata/voxels_constants.h>


namespace emdata {

// Yes, this could be shielded from view but outside routines may
// want to do optimizations on the raw data.
const uint16_t  MOST_SIGNIFICANT_16BIT = 0x8000;
const uint16_t  LARGEST_15BITS = 0x7FFF;
const double    LAMBDA_INCR = 2.0 * 3.1415926 / 256.0;
const double    LAMBDA_HALF_INCR = LAMBDA_INCR / 2.0;
const double    PHI_INCR = 3.1415926 / 128.0;
const double    PHI_HALF_INCR = PHI_INCR / 2.0;

const int       SPAN_HEADER_SIZE = 6;
const int       SLICE_HEADER_SIZE = 6;

// Convenience function to return a description of how the data was encoded
std::string EncodingStyle(const std::string& encodedData);

// Convenience function to append one provided string to another.
void AppendEncoding(const std::string& encodedData, 
                    std::string *concatenatedEncodings);


/*
 *  Note: mixing 8-bit and 16-bit encoding will throw an exception,
 *    as will changing the z-coordinates of the points within a run.
 */
class VoxelEncoder
{
  public:
    // Constructor that reads or creates pre-computed normals table.
    VoxelEncoder(VoxelValue::type valueType = VoxelValue::BITS8, 
                 Slicing::type sliceType = Slicing::Z,
                 bool normalStored = false, NormalsTable* pTable=0,
                 bool debug = false);

    // Replace current encoding with previously encoded data
    void SetEncoding(const std::string& encodedData);

    // Append to current encoding previously encoded data.
    // If current and appended encoding do not match in terms
    // of value type, slicing direction, and normal stored,
    // an exception will be thrown.
    void AppendEncoding(const std::string& encodedData);

    // Return results of encoding up until this point
    std::string& GetEncoding();

    // Clear encoding
    void ClearEncoding();

    // Iteration support
    void SeekToFirst();
    bool Valid();
    void Next(const bool decodeNormals = true);

    void GetVoxelPt(VoxelPt *pPoint);
    uint8_t Get8BitValue();
    uint16_t Get16BitValue();

    bool IsSurface();
    void GetNormal(Vector3d *pNormal);
    uint16_t GetEncodedNormal();
    double GetMagnitude();


    // Append voxel with 8-bit grayscale
    void AppendVoxel(const VoxelPt& pt, const uint8_t value);
    void AppendSurface(const VoxelPt& pt, const uint8_t value, const Vector3d& normal);
    void AppendInterior(const VoxelPt& pt, const uint8_t value, const double magnitude);

    // Append voxel with 16-bit grayscale
    void AppendVoxel(const VoxelPt& pt, const uint16_t value);
    void AppendSurface(const VoxelPt& pt, const uint16_t value, const Vector3d& normal);
    void AppendInterior(const VoxelPt& pt, const uint16_t value, const double magnitude);

  private:
    void SetFlagsByte();

    // These private methods advance internal iteration
    void ReadFlagsByte();
    void ReadSliceHeader();
    void ReadSpanHeader();
    void ReadValue(const bool decodeNormals = true);
    void ReadNormal(const uint16_t buffer);
    void ResetHead();

    uint16_t Get16Bit(int dataPosition);
    uint32_t Get32Bit(int dataPosition);

    // Call to force any span/slice buffers into main string
    void AssimilateBuffers();

    // Lower-level methods that modify/check current span
    bool IsNewSlice(const VoxelPt& pt);
    bool IsNewSpan(const VoxelPt& pt);
    void CheckSpan(const VoxelPt& pt);

    void AppendCurrentSlice();
    void AppendCurrentSpan();

    void Append16Bit(const uint16_t value, std::string *pBuffer);
    void Append32Bit(const uint32_t value, std::string *pBuffer);

    uint16_t EncodeNormal(const Vector3d& normal);

    VoxelValue::type valueType_;
    Slicing::type    sliceType_;
    bool             normalStored_;
    NormalsTable*    pNormalsTable_;
    bool        decodeNormals_;     // On when last READ also decoded normals
    bool        debug_;

    size_t      valueSize_;

    // Variables to track iteration
    int         curLocation_;      // The head of the reader
    int         spansRemaining_;
    int         spansRead_;
    int         voxelsRemaining_;
    int         voxelsRead_;

    // Value of voxel under current reading head
    bool        curValid_;      // Have we actually read value?
    VoxelPt     curPt_;
    uint8_t     cur8bitValue_;
    uint16_t    cur16bitValue_;
    bool        curIsSurface_;
    double      curMagnitude_;
    Vector3d    curNormal_;
    uint16_t    curEncodedNormal_;

    // Variables to track current encoding/appending
    std::string data_;      // The actual encoded data
    int         spansEncoded_;
    int         voxelsEncoded_;

    std::string sliceBuffer_;
    int         sliceBufferSpans_;
    std::string spanBuffer_;
    int         spanBufferVoxels_;
    Bounds3d    bounds_;
    bool        boundsUncomputed_;
    VoxelPt     startPt_;
    VoxelPt     lastPt_;
};

}  // emdata namespace

#endif
