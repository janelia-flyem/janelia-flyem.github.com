// Copyright 2012 HHMI.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of HHMI nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: katzw@janelia.hhmi.org (Bill Katz)
//  Written as part of the FlyEM Project at Janelia Farm Research Center.

#include <math.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>

#include "utils.h"

using std::string;
using std::ostringstream;
using std::cout;
using std::endl;

namespace emdata {

string bool_string(const bool value)
{
    if (value)
        return string("True");
    else
        return string("False");
}

string elapsed_time(const clock_t begin, bool minutes)
{
    clock_t end = clock();
    double elapsedSec = (end - begin) / double(CLOCKS_PER_SEC);

    ostringstream ss;
    if (minutes || elapsedSec > 120.0) {
        double minutes = elapsedSec / 60.0;
        ss << minutes << " minutes";
    } else {
        ss << elapsedSec << " seconds";
    }
    return ss.str();
}

string pt_to_string(const VoxelPt& pt)
{
    ostringstream ss;
    ss << "(" << pt.x << "," << pt.y << "," << pt.z << ")";
    return ss.str();
}

string vec_to_string(const Vector3d& pt)
{
    ostringstream ss;
    ss << "(" << pt.x << "," << pt.y << "," << pt.z << ")";
    return ss.str();
}

string slicing_to_string(Slicing::type sliceType)
{
    if (sliceType == Slicing::Z) {
        return "Z";
    } else if (sliceType == Slicing::Y) {
        return "Y";
    } else if (sliceType == Slicing::X) {
        return "X";
    }
}

void modify_bounds(const Bounds3d& newBounds, Bounds3d *pBounds)
{
    if (pBounds->minPoint.x > newBounds.minPoint.x)
        pBounds->minPoint.x = newBounds.minPoint.x;
    if (pBounds->minPoint.y > newBounds.minPoint.y)
        pBounds->minPoint.y = newBounds.minPoint.y;
    if (pBounds->minPoint.z > newBounds.minPoint.z)
        pBounds->minPoint.z = newBounds.minPoint.z;
    if (pBounds->maxPoint.x < newBounds.maxPoint.x)
        pBounds->maxPoint.x = newBounds.maxPoint.x;
    if (pBounds->maxPoint.y < newBounds.maxPoint.y)
        pBounds->maxPoint.y = newBounds.maxPoint.y;
    if (pBounds->maxPoint.z < newBounds.maxPoint.z)
        pBounds->maxPoint.z = newBounds.maxPoint.z;
}

bool file_exists(const string& filename)
{
    std::ifstream ifile(filename.c_str());
    if (ifile)
        return true;
    else
        return false;
}

void create_directory(const string& dirName)
{
    ostringstream ss;
    ss << "mkdir -p " << dirName;
    system(ss.str().c_str());
}


// Utilities for reading a CSV file with body of interest data.
// CSV file is assume to be composed of following:
// body ID, name, cell type, location, primary, secondary, comment

void load_boi_info_map(const string& boiCsvFilename, LabelToBodyInfoMap *pMap)
{
    pMap->clear();

    cout << endl;
    cout << std::setw(8) << std::left << "Label"
         << std::setw(10) << std::left << "Body ID"
         << std::setw(20) << std::left << "Body Name" << endl;

    BodyInfo bodyInfo;
    LabelId bodyId;
    std::ifstream csvFile(boiCsvFilename.c_str());
    string line;
    int linenum = 0;
    while (getline(csvFile, line)) {
        ++linenum;
        if (linenum > 1) {      // Ignore header line
            std::istringstream linestream(line);
            string item;
            int itemnum = 0;
            while (getline(linestream, item, ',')) {
                ++itemnum;
                if (itemnum == 1) {
                    if (item.size() == 0) {
                        bodyId = 0;
                        break;      // Invalid body ID, move to next line
                    }
                    bodyId = LabelId(atoi(item.c_str()));
                    bodyInfo.bodyId = bodyId;
                    bodyInfo.boiId = linenum;  // boi # = line # in CSV file
                } else if (itemnum == 2) {
                    bodyInfo.name = item;
                } else if (itemnum == 3) {
                    bodyInfo.cellType = item;
                } else if (itemnum == 4) {
                    bodyInfo.location = item;
                }
            }
            if (bodyId != 0) {
                (*pMap)[bodyId] = bodyInfo;
                cout << std::setw(8) << std::left << bodyInfo.boiId
                     << std::setw(10) << std::left << bodyInfo.bodyId
                     << std::setw(20) << std::left << bodyInfo.name 
                     << endl;
            }
        }
    }
    cout << endl;
}

void load_boi_set(const string& boiCsvFilename, LabelSetData *pSet)
{
    pSet->clear();

    cout << endl;
    cout << std::setw(8) << std::left << "Label"
         << std::setw(10) << std::left << "Body ID" << endl;

    LabelId bodyId;
    std::ifstream csvFile(boiCsvFilename.c_str());
    string line;
    int linenum = 0;
    while (getline(csvFile, line)) {
        ++linenum;
        if (linenum > 1) {      // Ignore header line
            std::istringstream linestream(line);
            string item;
            getline(linestream, item, ',');
            if (item.size() != 0) {
                bodyId = LabelId(atoi(item.c_str()));
                pSet->insert(bodyId);
                cout << std::setw(8) << std::left << linenum
                     << std::setw(10) << std::left << bodyId
                     << endl;
            }
        }
    }
    cout << endl;
}


}  // emdata namespace
