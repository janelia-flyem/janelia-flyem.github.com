/**
 * Base EM Data Types
 * Copyright 2012 HHMI.  All rights reserved.
 *
 * Bill Katz (katzw@janelia.hhmi.org)
 *
 * This file specifies the basic data types used for segmentation and 
 * visualization of FlyEM datasets.
 *
 * The available types in Thrift are:
 *
 * bool        Boolean, one byte
 * byte        Signed byte
 * i16         Signed 16-bit integer
 * i32         Signed 32-bit integer
 * i64         Signed 64-bit integer
 * double      64-bit floating point value
 * string      String
 * map<t1,t2>  Map from one type to another
 * list<t1>    Ordered list of one type
 * set<t1>     Set of unique elements of one type
 */

namespace cpp emdata
namespace java emdata


typedef i64         LabelId         // Gives us plenty of headroom

typedef i16         ImageLod        // # of original voxels per voxel along one dimension
                                    //  2^n =>  0 = 1-to-1,  1 = 2-to-1,  2 = 4-to-1

typedef i16         VoxelCoord      // This can be signed (offset) so only use 15-bits.
typedef i64         VoxelIndex

typedef double      Confidence      // TODO: Should we constrain this more, e.g. 0 <= x <= 1.0

enum ImageType {
    GRAYSCALE = 1,
    LABEL,
    ZEROEDGE,           // All 0 values mark edges
    AFFINITYGRAPH
}


/**
 * Basic data types
 */

struct Vector3d {
    1:  double  x,
    2:  double  y,
    3:  double  z
}

struct Color {
    1:  byte    r,
    2:  byte    g,
    3:  byte    b,
    4:  byte    a
}

// For initial programs, we assume rectilinear grid cannot exceed 15 bits in any direction.
// This gives us 32,767 voxels in each direction, which is 20k more than largest TEM.
struct VoxelPt {
    1:  VoxelCoord  x,
    2:  VoxelCoord  y,
    3:  VoxelCoord  z
}

struct Bounds3d {
    1:  VoxelPt minPoint,
    2:  VoxelPt maxPoint
}

struct KeyValue {
    1:  string          key,
    2:  string          value
}
typedef list<KeyValue>  KeyValues


/**
 * Images
 *
 * Always addressed in 3D space.
 */

struct Image {
    1:  ImageType   imageType,
    2:  ImageLod    lod,
    3:  Bounds3d    bounds,
    4:  Vector3d    resolution,
    5:  optional list<byte>      data8,
    6:  optional list<i16>       data16,
    7:  optional list<i32>       data32,
    8:  optional list<LabelId>   dataLabel
}
