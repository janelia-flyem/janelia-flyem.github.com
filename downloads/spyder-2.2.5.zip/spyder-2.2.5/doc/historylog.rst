History log
===========

The history log plugin collects command histories of Python/IPython interpreters
or command windows.

.. image:: images/historylog.png

Related plugins:

* :doc:`console`
