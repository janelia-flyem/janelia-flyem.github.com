__version__ = "0.17.1"

# Void cython.* directives (for case insensitive operating systems).
from Cython.Shadow import *
