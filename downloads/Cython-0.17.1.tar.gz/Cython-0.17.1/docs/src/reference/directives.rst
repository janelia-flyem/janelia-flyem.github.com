Compiler Directives
===================

TODO. See http://wiki.cython.org/enhancements/compilerdirectives