from .core import EqualityHashKey
from .parallel import fold
