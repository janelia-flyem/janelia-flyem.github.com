# pylint: disable=no-absolute-import
import syntax_error
