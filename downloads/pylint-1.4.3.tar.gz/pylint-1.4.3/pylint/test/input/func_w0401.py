"""test cyclic import
"""
# pylint: disable=print-statement, no-absolute-import
__revision__ = 0

from input import w0401_cycle

if __revision__:
    print w0401_cycle
