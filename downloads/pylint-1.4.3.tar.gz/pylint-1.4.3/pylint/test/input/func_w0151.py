"""check black listed builtins
"""

__revision__ = map(str, (1, 2, 3))

