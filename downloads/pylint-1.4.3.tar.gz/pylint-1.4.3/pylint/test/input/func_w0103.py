"""test max branch
"""
from __future__ import print_function
__revision__ = ''

def stupid_function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9):
    """reallly stupid function"""
    print(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
