=======
Shapely
=======

Documentation Contents
======================

.. toctree::
   :maxdepth: 2

   The Project <project>
   User Manual <manual>
   API Documentation <modules>

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
