"package containing various sphinx extensions"

#legacy aliases
from __future__ import absolute_import
from . import (autodoc_sections as nested_sections,
               index_styling as index_styles,
               )
