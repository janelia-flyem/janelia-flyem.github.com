.. index:: cloud; license

.. include:: ../LICENSE
