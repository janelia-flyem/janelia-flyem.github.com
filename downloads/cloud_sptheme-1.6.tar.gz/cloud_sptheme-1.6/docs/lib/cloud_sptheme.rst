===================================================================================
:mod:`cloud_sptheme` - helper functions
===================================================================================

.. module:: cloud_sptheme
    :synopsis: helper functions

The main :mod:`!cloud_sptheme` module contains the following helper functions:

.. autofunction:: get_theme_dir

.. autofunction:: get_version
