.. index:: cloud; changelog

.. include:: ../CHANGES
