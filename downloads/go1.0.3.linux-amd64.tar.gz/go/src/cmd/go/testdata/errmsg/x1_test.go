package foo_test

import "bar"
