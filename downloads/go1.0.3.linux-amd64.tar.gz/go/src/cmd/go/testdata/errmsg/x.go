package foo

import "bar"
