try:
    from viewers import ImageViewer, CollectionViewer
except ImportError:
    print("Could not import PyQt4 -- ImageViewer not available.")
