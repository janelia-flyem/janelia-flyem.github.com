API
===

.. toctree::
   :maxdepth: 2

   hdf5storage
   hdf5storage.lowlevel
   hdf5storage.Marshallers
   hdf5storage.utilities

