a = load('python_v7p3.mat');
save('python_v7.mat','-struct','a','-v7');

exit;
