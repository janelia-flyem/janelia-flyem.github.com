.. include:: includes/big_toc_css.rst

.. _data-transforms:

Dataset transformations
-----------------------

.. toctree::

    modules/preprocessing
    modules/feature_extraction
    modules/kernel_approximation
    modules/random_projection
    modules/metrics
