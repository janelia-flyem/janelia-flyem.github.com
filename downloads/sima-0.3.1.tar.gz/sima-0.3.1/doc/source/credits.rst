.. include:: ../../CREDITS.rst
