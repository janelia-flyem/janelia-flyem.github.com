********
SIMA API
********

The public API of the SIMA package is described below.
Functionality not described in this documentation may not 
remain stable across versions and should therefore not be used.

.. toctree::
   :maxdepth: 1

   datasets
   motion
   segment
   rois
   extract
