======================
ImagingDataset objects
======================

.. automodule:: sima.imaging

.. autoclass:: sima.ImagingDataset
    :members:
    :member-order: bysource

.. automodule:: sima.iterables
    :members:
