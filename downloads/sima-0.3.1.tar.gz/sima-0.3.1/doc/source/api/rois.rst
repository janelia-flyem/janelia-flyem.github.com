==========================
Regions of Interest (ROIs)
==========================

.. automodule:: sima.ROI

ROI class
=========

.. autoclass:: sima.ROI.ROI
    :members:
    :member-order: bysource

ROIList class
=============

.. autoclass:: sima.ROI.ROIList
    :members:

