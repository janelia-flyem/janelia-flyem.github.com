=================
Signal extraction
=================

.. automethod:: sima.imaging.ImagingDataset.extract

Details
-------
.. automodule:: sima.extract
