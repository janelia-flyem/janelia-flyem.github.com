.. automodule:: sima.motion
    :members:
