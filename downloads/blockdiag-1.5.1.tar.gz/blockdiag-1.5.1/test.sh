#!/bin/sh

bin/blockdiag --debug -Tsvg -o blockdiag.svg $1 $2 $3 $4 $5
#bin/blockdiag --debug -Tpng -o blockdiag.png $1 $2 $3 $4 $5
