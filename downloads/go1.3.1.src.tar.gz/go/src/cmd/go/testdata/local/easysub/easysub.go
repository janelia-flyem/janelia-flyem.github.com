package easysub

import "fmt"

func Hello() {
	fmt.Println("easysub.Hello")
}
